
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ultimateend.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.world.BiomeLoadingEvent;

import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Holder;

import net.mcreator.ultimateend.world.features.plants.EndTomatoFeature;
import net.mcreator.ultimateend.world.features.ores.EnderiteOreFeature;
import net.mcreator.ultimateend.world.features.ores.DarkStoneFeature;
import net.mcreator.ultimateend.world.features.MobArenaFeature;
import net.mcreator.ultimateend.world.features.LargeAmethystTreeFeature;
import net.mcreator.ultimateend.world.features.EndCabinFeature;
import net.mcreator.ultimateend.world.features.AmethystTreeFeature;
import net.mcreator.ultimateend.UltimateendMod;

import java.util.function.Supplier;
import java.util.Set;
import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber
public class UltimateendModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, UltimateendMod.MODID);
	private static final List<FeatureRegistration> FEATURE_REGISTRATIONS = new ArrayList<>();
	public static final RegistryObject<Feature<?>> AMETHYST_TREE = register("amethyst_tree", AmethystTreeFeature::feature, new FeatureRegistration(
			GenerationStep.Decoration.SURFACE_STRUCTURES, AmethystTreeFeature.GENERATE_BIOMES, AmethystTreeFeature::placedFeature));
	public static final RegistryObject<Feature<?>> ENDERITE_ORE = register("enderite_ore", EnderiteOreFeature::feature, new FeatureRegistration(
			GenerationStep.Decoration.UNDERGROUND_ORES, EnderiteOreFeature.GENERATE_BIOMES, EnderiteOreFeature::placedFeature));
	public static final RegistryObject<Feature<?>> END_TOMATO = register("end_tomato", EndTomatoFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.VEGETAL_DECORATION, EndTomatoFeature.GENERATE_BIOMES, EndTomatoFeature::placedFeature));
	public static final RegistryObject<Feature<?>> LARGE_AMETHYST_TREE = register("large_amethyst_tree", LargeAmethystTreeFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.SURFACE_STRUCTURES, LargeAmethystTreeFeature.GENERATE_BIOMES,
					LargeAmethystTreeFeature::placedFeature));
	public static final RegistryObject<Feature<?>> MOB_ARENA = register("mob_arena", MobArenaFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.SURFACE_STRUCTURES, MobArenaFeature.GENERATE_BIOMES, MobArenaFeature::placedFeature));
	public static final RegistryObject<Feature<?>> DARK_STONE = register("dark_stone", DarkStoneFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.UNDERGROUND_ORES, DarkStoneFeature.GENERATE_BIOMES, DarkStoneFeature::placedFeature));
	public static final RegistryObject<Feature<?>> END_CABIN = register("end_cabin", EndCabinFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.SURFACE_STRUCTURES, EndCabinFeature.GENERATE_BIOMES, EndCabinFeature::placedFeature));

	private static RegistryObject<Feature<?>> register(String registryname, Supplier<Feature<?>> feature, FeatureRegistration featureRegistration) {
		FEATURE_REGISTRATIONS.add(featureRegistration);
		return REGISTRY.register(registryname, feature);
	}

	@SubscribeEvent
	public static void addFeaturesToBiomes(BiomeLoadingEvent event) {
		for (FeatureRegistration registration : FEATURE_REGISTRATIONS) {
			if (registration.biomes() == null || registration.biomes().contains(event.getName()))
				event.getGeneration().getFeatures(registration.stage()).add(registration.placedFeature().get());
		}
	}

	private static record FeatureRegistration(GenerationStep.Decoration stage, Set<ResourceLocation> biomes,
			Supplier<Holder<PlacedFeature>> placedFeature) {
	}
}
